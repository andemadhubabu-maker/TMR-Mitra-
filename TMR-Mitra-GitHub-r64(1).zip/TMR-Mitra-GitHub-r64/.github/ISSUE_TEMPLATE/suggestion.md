---
name: Suggestion
about: An idea to improve the app
---

**What happened / what should change**

**Scenario or screen** (category, scenario name)

**Phone and Chrome version** (optional)

_Please do not post names, phone numbers or photos here._
